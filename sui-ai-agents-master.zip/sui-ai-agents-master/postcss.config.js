// Copyright (c) Mysten Labs, Inc.
// SPDX-License-Identifier: Apache-2.0
// eslint-disable-next-line import/no-anonymous-default-export
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
